#pragma once

#include <QDialog>
#include "ui_BookBorrow.h"

class BookBorrow : public QDialog
{
	Q_OBJECT

public:
	BookBorrow(QWidget *parent = nullptr);
	~BookBorrow();

private:
	Ui::BookBorrowClass ui;
};
