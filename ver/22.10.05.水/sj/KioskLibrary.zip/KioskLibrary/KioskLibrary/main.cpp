#include "KioskLibrary.h"
#include <QtWidgets/QApplication>
#include "Dialog.h"
#include "BookBorrow.h"
#include "BookReturn.h"


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    KioskLibrary w;


    w.show();
    return a.exec();
}
