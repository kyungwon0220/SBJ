#pragma once

#include <QDialog>
#include "ui_BookReturn.h"

class BookReturn : public QDialog
{
	Q_OBJECT

public:
	BookReturn(QWidget *parent = nullptr);
	~BookReturn();

private:
	Ui::BookReturnClass ui;
};
