﻿#include <iostream>
#include <fstream> 
#include <vector>
#include <sstream>
#include <string>
using namespace std;


int BookRental(int SerchVelue, string BooknameVelue, string RequesterVelue) {
    string TemporalBuffer = {};
    string ProBuffer = {};
    string BeforeBuffer = {};
    string EditBuffer = {};
    vector<string>bufferout;
    string CompareBuffer = {};
    int flagshare = 0;
    int AccountLine = 0;
    int Counter = 0;
    int BufferLength = 0;
    string LoginReadingBuffer = {};
    string AccountTemporal = {};
    string AccountProTemporal = {};
    string AccountEditTemporal = {};
    // Book_Info.csv 파일을 연다 
    ifstream BookFile("Book_info.csv");
    //줄을 읽어옵니다. 언제까지? 파일끝까지.
    while (BookFile.peek() != EOF) {
        bufferout.clear();
        //엑셀파일에서 버퍼로 한줄을 읽어옵니다!
        getline(BookFile, TemporalBuffer);
        ProBuffer = TemporalBuffer;
        istringstream ss(TemporalBuffer);
        //읽어온것을 ',' 를 기준으로 배열로 만듭니다.
        while (getline(ss, TemporalBuffer, ',')) {
            bufferout.push_back(TemporalBuffer);
        }
        // 배열의 5번째값 = 책 제목
        CompareBuffer = bufferout[SerchVelue];
        //bufferout의 특정배열이 기준과 내용이 같다면, 책이 실존하는것이고.
        if (CompareBuffer.compare(BooknameVelue) == 0) {
            if (bufferout[5].compare("0") == 0) {
                //책재고 0개
                return 1;
            }
            else {
                //bufferout[5]의 내용을 -1 한다, 그리고 각 배열별로 string으로 바꿔서 넣는다.
                int Bufferint = stoi(bufferout[5]);
                Bufferint--;
                //이제 bufferint의 값을 다시 string으로 바꾸고 bufferout[5]의 값과 교환한다.               
                bufferout[5] = to_string(Bufferint);
                while (Counter < 9) {
                    EditBuffer.append(bufferout[Counter]);
                    Counter++;
                    if (Counter != 9) { EditBuffer.append(","); }

                }
                //조건돌파문
                flagshare = 1;
                //EditBuffer 내용이 BeforeBuffer에 append 되면 안되므로, continue로 건너뛴다.
                continue;
            }
        }
        BeforeBuffer.append(ProBuffer);
        BeforeBuffer.append("\n");
    }
    if (flagshare != 1) {
        //일치하는 책이 존재하지않음
        return 2;
    }

    BookFile.close();
    BeforeBuffer.append(EditBuffer);
    BeforeBuffer.append("\n");
    if (flagshare == 1) {
        //Book_Info 재구축
        ofstream BookFileRewrite;
        BookFileRewrite.open("Book_info.csv");

        BookFileRewrite << BeforeBuffer << endl;
        BookFileRewrite.close();

        // 계정의 내용수정
        ifstream AccountFile("Account_info.csv");
        while (AccountFile.peek() != EOF) {
            bufferout.clear();
            //엑셀파일에서 버퍼로 한줄을 읽어왔다
            getline(AccountFile, LoginReadingBuffer);
            AccountProTemporal = LoginReadingBuffer;
            istringstream ss(LoginReadingBuffer);
            //vector인 bufferout에 buffer의 내용이 들어갔다.
            while (getline(ss, LoginReadingBuffer, ',')) {
                bufferout.push_back(LoginReadingBuffer);
            }
            CompareBuffer = bufferout[0];
            //bufferout의 특정배열이 기준과 내용이 같다면
            if (CompareBuffer.compare(RequesterVelue) == 0) {
                bufferout[5].append(BooknameVelue);
                bufferout[5].append("^");
                int Bufferint = stoi(bufferout[6]);
                Bufferint--;
                bufferout[6] = to_string(Bufferint);
                Counter = 0;
                while (Counter < 9) {
                    AccountEditTemporal.append(bufferout[Counter]);
                    Counter++;
                    if (Counter != 9) { AccountEditTemporal.append(","); }
                }
                continue;

                //bufferint의 값을 string으로 바꾸고 다시 배열에 집어넣는다.
                //그리고 전환한 값을 다시 string으로 바꾸되, 콤마를 중간에 삽입.
            }
            AccountTemporal.append(AccountProTemporal);
            AccountTemporal.append("\n");
        }
        AccountFile.close();
        AccountTemporal.append(AccountEditTemporal);
        AccountTemporal.append("\n");
        //Book_Info 재구축
        ofstream RewriteAccountFile;
        RewriteAccountFile.open("Account_info.csv");

        RewriteAccountFile << AccountTemporal << endl;
        RewriteAccountFile.close();
    }
    return 0;
}
int main() {
    int a = 4;
    string b = "테스트북a";
    string c = "admin";
    int d = BookRental(a, b, c);
    if (d == 0) {
        cout << "대여성공";
    }
    else if (d == 1) {
        cout << "오류1 재고없음";
    }
    else if (d == 2) {
        cout << "오류2 책 자체가없다";
    }
    return 0;
}