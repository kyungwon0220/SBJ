﻿#include <iostream>
#include <fstream> 
#include <string>
#include <vector>
#include <sstream>
using namespace std;


int BookRental(int SerchVelue, string BooknameVelue, string RequesterVelue) {
    string TemporalBuffer;
    string ProBuffer;
    string BeforeBuffer = {};
    string EditBuffer;
    vector<string>bufferout;
    string CompareBuffer;
    int flagshare = 0;
    int AccountLine = 0;
    string LoginReadingBuffer;
    string AccountTemporal = {};
    string AccountProTemporal;
    // Book_Info.csv 파일을 연다 
    ifstream myfile("Book_Info.csv");
    //줄을 읽어옵니다. 언제까지? 파일끝까지.
    while (myfile.peek() != EOF) {
        bufferout.clear();
        //엑셀파일에서 버퍼로 한줄을 읽어옵니다!
        getline(myfile, TemporalBuffer);
        ProBuffer = TemporalBuffer;
        istringstream ss(TemporalBuffer);
        //읽어온것을 ',' 를 기준으로 배열로 만듭니다.
        while (getline(ss, TemporalBuffer, ',')) {
            bufferout.push_back(TemporalBuffer);
        }
        // 배열의 5번째값 = 책 제목
        CompareBuffer = bufferout[SerchVelue];
        //bufferout의 특정배열이 기준과 내용이 같다면, 책이 실존하는것이고.
        if (CompareBuffer.compare(BooknameVelue) == 0) {
            if (bufferout[5].compare("0")== 0) {
                //bufferout[5]의 내용을 -1 한다, 그리고 각 배열별로 string으로 바꿔서 넣는다.
                int Bufferint = stoi(bufferout[5]);
                Bufferint--;
                //이제 bufferint의 값을 다시 string으로 바꾸고 bufferout[5]의 값과 교환한다.
                
                bufferout[5] = to_string(Bufferint);
                //이제부터 배열을 string으로 넣되, ","를 중간에 넣을것이다.

                myfile.close();

                ifstream myfile("Account_info.csv");
                while (myfile.peek() != EOF) {
                    bufferout.clear();
                    //엑셀파일에서 버퍼로 한줄을 읽어왔다
                    getline(myfile, LoginReadingBuffer);
                    AccountProTemporal = LoginReadingBuffer;
                    istringstream ss(LoginReadingBuffer);
                    //vector인 bufferout에 buffer의 내용이 들어갔다.
                    while (getline(ss, LoginReadingBuffer, ',')) {
                        bufferout.push_back(LoginReadingBuffer);
                    }
                    CompareBuffer = bufferout[0];
                    //bufferout의 특정배열이 기준과 내용이 같다면
                    if (CompareBuffer.compare(RequesterVelue) == 0) {
                        int Bufferint = stoi(bufferout[4]);
                        Bufferint--;
                       //bufferint의 값을 string으로 바꾸고 다시 배열에 집어넣는다.
                       //그리고 전환한 값을 다시 string으로 바꾸되, 콤마를 중간에 삽입.
                    }
                    AccountTemporal.append(AccountProTemporal);
                    AccountTemporal.append("\n");
                }

                
                flagshare = 1;
                continue;
                
                    

                }
            
            else {
                //책의 재고가 없습니다.
                return 1;
            }
        BeforeBuffer.append(ProBuffer);
        BeforeBuffer.append("\n");
        }
    BeforeBuffer.append(EditBuffer);
    BeforeBuffer.append("\n");

    ofstream myfile;
    myfile.open("Book_Info.csv", ios::out | ios::app | ios::trunc);
    if (myfile.is_open()) {
        myfile << BeforeBuffer;
        myfile.close();
    }
    
    //만일 수정항목이 있다면
    if (flagshare == 1) {
        return 0;
    }
    //만일 수정항목도 없고 EOF까지 그저 읽기만 했다면
    return 2;
}
