#include "selectClass.h"
#include "LOGINUSERINFO.h"
#include <QTextStream>
#include <QDate>


selectClass::selectClass(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}

selectClass::~selectClass()
{}
void selectClass::change_borrowClass() {
	hide();
	borrow = new borrowClass(this);
	borrow->show();
}

void selectClass::change_requestClass() {
	hide();
	request = new requestClass(this);
	request->show();
}

void selectClass::change_accountinfoClass() {
	hide();
	accountinfo = new accountinfoClass(this);
	accountinfo->show();
}

void selectClass::logout() {
	close();
	QWidget* parent = this ->parentWidget();
	parent->show();
	
}

void selectClass::borrowuserinfo() {
	QTextStream out(stdout);

	QDate borrowdate = QDate::currentDate();

	out << "Current date is: " << borrowdate.toString();

	extern vector<string> loginuserinfo;
	vector<string> addborrowdate = getloginuserinfo(loginuserinfo[0]);
}

void selectClass::returnuserinfo() {
}