#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_KioskLibrary.h"
#include <QMessageBox>
#include "Dialog.h"
#include <iostream>

class KioskLibrary : public QMainWindow
{
    Q_OBJECT

public:
    KioskLibrary(QWidget* parent = nullptr);
    ~KioskLibrary();

private:
    Ui::KioskLibraryClass ui;



public slots:
    void pushButton_Login_clicked();
    void pushButton_Register_clicked();
};
