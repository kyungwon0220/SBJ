/********************************************************************************
** Form generated from reading UI file 'KioskLibrary.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_KIOSKLIBRARY_H
#define UI_KIOSKLIBRARY_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_KioskLibraryClass
{
public:
    QWidget *centralWidget;
    QLabel *label;
    QLineEdit *lineEdit_Passward;
    QPushButton *pushButton_Login;
    QPushButton *pushButton_Register;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *lineEdit_Id;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *KioskLibraryClass)
    {
        if (KioskLibraryClass->objectName().isEmpty())
            KioskLibraryClass->setObjectName(QString::fromUtf8("KioskLibraryClass"));
        KioskLibraryClass->resize(911, 779);
        centralWidget = new QWidget(KioskLibraryClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(160, 70, 601, 171));
        label->setAlignment(Qt::AlignCenter);
        label->setWordWrap(false);
        label->setMargin(0);
        label->setIndent(-1);
        lineEdit_Passward = new QLineEdit(centralWidget);
        lineEdit_Passward->setObjectName(QString::fromUtf8("lineEdit_Passward"));
        lineEdit_Passward->setGeometry(QRect(400, 340, 211, 31));
        lineEdit_Passward->setStyleSheet(QString::fromUtf8("font-size:14pt;"));
        pushButton_Login = new QPushButton(centralWidget);
        pushButton_Login->setObjectName(QString::fromUtf8("pushButton_Login"));
        pushButton_Login->setGeometry(QRect(460, 410, 151, 61));
        pushButton_Login->setAutoDefault(false);
        pushButton_Login->setFlat(false);
        pushButton_Register = new QPushButton(centralWidget);
        pushButton_Register->setObjectName(QString::fromUtf8("pushButton_Register"));
        pushButton_Register->setGeometry(QRect(280, 410, 151, 61));
        layoutWidget = new QWidget(centralWidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(280, 260, 90, 121));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout->addWidget(label_2);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout->addWidget(label_3);

        lineEdit_Id = new QLineEdit(centralWidget);
        lineEdit_Id->setObjectName(QString::fromUtf8("lineEdit_Id"));
        lineEdit_Id->setGeometry(QRect(400, 270, 211, 31));
        lineEdit_Id->setStyleSheet(QString::fromUtf8("font-size:14pt;"));
        KioskLibraryClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(KioskLibraryClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 911, 21));
        KioskLibraryClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(KioskLibraryClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        KioskLibraryClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(KioskLibraryClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        KioskLibraryClass->setStatusBar(statusBar);

        retranslateUi(KioskLibraryClass);

        pushButton_Login->setDefault(false);


        QMetaObject::connectSlotsByName(KioskLibraryClass);
    } // setupUi

    void retranslateUi(QMainWindow *KioskLibraryClass)
    {
        KioskLibraryClass->setWindowTitle(QCoreApplication::translate("KioskLibraryClass", "KioskLibrary", nullptr));
        label->setText(QCoreApplication::translate("KioskLibraryClass", "<html><head/><body><p><span style=\" font-size:36pt; font-weight:600;\">\353\241\234\352\267\270\354\235\270 \353\260\217 \355\232\214\354\233\220\352\260\200\354\236\205</span></p></body></html>", nullptr));
        lineEdit_Passward->setText(QString());
        pushButton_Login->setText(QCoreApplication::translate("KioskLibraryClass", "\353\241\234\352\267\270\354\235\270", nullptr));
        pushButton_Register->setText(QCoreApplication::translate("KioskLibraryClass", "\355\232\214\354\233\220\352\260\200\354\236\205", nullptr));
        label_2->setText(QCoreApplication::translate("KioskLibraryClass", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:600;\">\354\225\204\354\235\264\353\224\224</span></p></body></html>", nullptr));
        label_3->setText(QCoreApplication::translate("KioskLibraryClass", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:600;\">\353\271\204\353\260\200\353\262\210\355\230\270</span></p></body></html>", nullptr));
        lineEdit_Id->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class KioskLibraryClass: public Ui_KioskLibraryClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_KIOSKLIBRARY_H
