#include "BookReturn.h"

BookReturn::BookReturn(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
}

BookReturn::~BookReturn()
{}
