#include "bookinfoClass.h"

bookinfoClass::bookinfoClass(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}

bookinfoClass::~bookinfoClass()
{}
