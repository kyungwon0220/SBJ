from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

#크롬 드라이버 자동 업데이트
from webdriver_manager.chrome import ChromeDriverManager

import time
import pyautogui
import pyperclip
import csv

#브라우저 꺼짐 방지
chrome_options = Options()
chrome_options.add_experimental_option("detach", True)

#불필요한 에러 메시지 없애기
chrome_options.add_experimental_option("excludeSwitches", ["enable-logging"])

service = Service(executable_path=ChromeDriverManager().install())
#ChromDriverManager를 통해서 크롬드라이버를 설치하고 Service객체에 넣기
driver = webdriver.Chrome(service=service, options=chrome_options)

#웹페이지 해당주소 이동
driver.implicitly_wait(5)#웹페이지가 로딩 될때까지 5초는 기다림
driver.maximize_window()#화면 최대화
driver.get('https://www.naver.com')

#쇼핑 메뉴 클릭
shop_btn = driver.find_element(By.CSS_SELECTOR,"#NM_FAVORITE > div.group_nav > ul.list_nav.type_fix > li:nth-child(5) > a")
shop_btn.click()

#검색 부분 클릭
search = driver.find_element(By.CSS_SELECTOR,"#_verticalGnbModule > div > div._header_header_REoTl > div > div._gnb_header_shop_Xd6Hq > div > div._gnbSearch_search_area_3LAyd > form > fieldset > div > input")
search.click()

#검색어 입력
search.send_keys('아이폰 13')
search.send_keys(Keys.ENTER)

#스크론 전 높이
#자바스크립트 명령어를 사용할 수 있는 명령어
before_h = driver.execute_script("return window.scrollY")

#무한 반복문
while True:
    #맨 아래로 스크롤을 내린다
    driver.find_element(By.CSS_SELECTOR,"body").send_keys(Keys.END)
    #스크롤 사이 페이지 로딩 시간
    time.sleep(1)

    #스크롤 후 높이
    after_h = driver.execute_script("return window.scrollY")

    if after_h == before_h:
        break
    before_h = after_h

#파일 생성
f = open(r"C:\Users\hejin\miniproject\네이버 쇼핑 크롤링\data.csv",'w',encoding='CP949', newline='')
csvWritter = csv.writer(f)


#상품 정보 div
items = driver.find_elements(By.CSS_SELECTOR,".basicList_info_area__TWvzp")

for item in items:
    name = item.find_element(By.CSS_SELECTOR,".basicList_title__VfX3c").text
    try:
        price = item.find_element(By.CSS_SELECTOR,".basicList_price_area__K7DDT").text
    except:
        price = "판매중단"
    link = item.find_element(By.CSS_SELECTOR,".basicList_title__VfX3c > a").get_attribute('href')

    print(name,price,link)
    csvWritter.writerow([name,price,link])

#파일 닫기
f.close()

