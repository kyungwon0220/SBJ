/********************************************************************************
** Form generated from reading UI file 'Dialog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_DialogClass
{
public:
    QPushButton *pushButton_Borrow;
    QPushButton *pushButton_Return;

    void setupUi(QDialog *DialogClass)
    {
        if (DialogClass->objectName().isEmpty())
            DialogClass->setObjectName(QString::fromUtf8("DialogClass"));
        DialogClass->resize(1083, 775);
        pushButton_Borrow = new QPushButton(DialogClass);
        pushButton_Borrow->setObjectName(QString::fromUtf8("pushButton_Borrow"));
        pushButton_Borrow->setGeometry(QRect(90, 210, 401, 361));
        pushButton_Borrow->setStyleSheet(QString::fromUtf8("font-size:120px;\n"
"\n"
""));
        pushButton_Return = new QPushButton(DialogClass);
        pushButton_Return->setObjectName(QString::fromUtf8("pushButton_Return"));
        pushButton_Return->setGeometry(QRect(590, 210, 401, 361));
        pushButton_Return->setStyleSheet(QString::fromUtf8("font-size:120px\n"
""));

        retranslateUi(DialogClass);

        QMetaObject::connectSlotsByName(DialogClass);
    } // setupUi

    void retranslateUi(QDialog *DialogClass)
    {
        DialogClass->setWindowTitle(QCoreApplication::translate("DialogClass", "Dialog", nullptr));
        pushButton_Borrow->setText(QCoreApplication::translate("DialogClass", "\353\214\200\354\227\254", nullptr));
        pushButton_Return->setText(QCoreApplication::translate("DialogClass", "\353\260\230\353\202\251", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogClass: public Ui_DialogClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
