#include "requestClass.h"

requestClass::requestClass(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}

requestClass::~requestClass()
{}
