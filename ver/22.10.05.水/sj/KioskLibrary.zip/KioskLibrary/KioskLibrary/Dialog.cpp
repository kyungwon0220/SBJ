#include "Dialog.h"

Dialog::Dialog(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);

	connect(ui.pushButton_Borrow, SIGNAL(clicked()), this,
		SLOT(pushButton_Borrow_clicked()));

	connect(ui.pushButton_Return, SIGNAL(clicked()), this,
		SLOT(pushButton_Return_clicked()));
}

Dialog::~Dialog()
{}

void Dialog::pushButton_Borrow_clicked()

{
	BookBorrow win_Borrow;
    hide();
    win_Borrow.show();
	win_Borrow.exec();

    }

void Dialog::pushButton_Return_clicked()

{
	BookReturn win_Return;
	hide();
	win_Return.show();
	win_Return.exec();

}
