#pragma once

#include <QMainWindow>
#include "ui_accountinfoClass.h"

class accountinfoClass : public QMainWindow
{
	Q_OBJECT

public:
	accountinfoClass(QWidget *parent = nullptr);
	~accountinfoClass();

private:
	Ui::accountinfoClassClass ui;


public slots:
	void goback();
};


