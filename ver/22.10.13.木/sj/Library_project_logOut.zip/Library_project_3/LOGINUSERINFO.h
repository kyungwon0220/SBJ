#include <iostream>
#include <fstream> 
#include <string>
#include <vector>
#include <sstream>
#include <stdio.h>
using namespace std;


vector<string> getloginuserinfo(string ab) {
    int AccountLine = 0;
    string AccountNameVelue = ab;
    string LoginReadingBuffer;
    vector<string>bufferout;
    string CompareBuffer;
    vector<string> loginuserinfo;

    ifstream myfile("Account_info.csv");
    while (myfile.peek() != EOF) {
        bufferout.clear();
        getline(myfile, LoginReadingBuffer);
        istringstream ss(LoginReadingBuffer);
        //vector�� bufferout�� buffer�� ������ ����.
        while (getline(ss, LoginReadingBuffer, ',')) {
            bufferout.push_back(LoginReadingBuffer);
        }
        CompareBuffer = bufferout[AccountLine];
        //bufferout�� Ư���迭�� ���ذ� ������ ���ٸ�
        if (CompareBuffer == ab) {
            loginuserinfo = bufferout;
        }
    }
return loginuserinfo;
}