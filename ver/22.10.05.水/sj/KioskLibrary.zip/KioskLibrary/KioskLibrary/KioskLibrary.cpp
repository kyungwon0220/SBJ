#include "KioskLibrary.h"


KioskLibrary::KioskLibrary(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);

    connect(ui.pushButton_Login, SIGNAL(clicked()), this,
        SLOT(pushButton_Login_clicked()));

    connect(ui.pushButton_Register, SIGNAL(clicked()), this,
        SLOT(pushButton_Register_clicked()));


}


void KioskLibrary::pushButton_Login_clicked()
{
    //QMessageBox::information(this, "Title", "Hello");
    QString id = ui.lineEdit_Id->text();
    QString passward = ui.lineEdit_Passward->text();
    if (id == "test" && passward == "test") {
        QMessageBox::information(this, "Login", "Id, Passward correct");
        Dialog win2;
        hide();
        win2.show();
        win2.exec();

    }
    else {
        QMessageBox::warning(this, "wrong","asf");
    }

}

void KioskLibrary::pushButton_Register_clicked()
{

}


KioskLibrary::~KioskLibrary()
{}


