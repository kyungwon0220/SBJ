#pragma once

#include <QDialog>
#include "ui_Dialog.h"
#include "BookBorrow.h"
#include "BookReturn.h"

class Dialog : public QDialog
{
	Q_OBJECT

public:
	Dialog(QWidget *parent = nullptr);
	~Dialog();

private:
	Ui::DialogClass ui;

public slots:
	void pushButton_Borrow_clicked();
	void pushButton_Return_clicked();
};