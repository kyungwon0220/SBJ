/********************************************************************************
** Form generated from reading UI file 'accountinfoClass.ui'
**
** Created by: Qt User Interface Compiler version 6.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ACCOUNTINFOCLASS_H
#define UI_ACCOUNTINFOCLASS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_accountinfoClassClass
{
public:
    QWidget *centralWidget;
    QTableWidget *tableWidget;
    QLabel *label;
    QPushButton *pushButton;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *accountinfoClassClass)
    {
        if (accountinfoClassClass->objectName().isEmpty())
            accountinfoClassClass->setObjectName("accountinfoClassClass");
        accountinfoClassClass->resize(551, 639);
        centralWidget = new QWidget(accountinfoClassClass);
        centralWidget->setObjectName("centralWidget");
        tableWidget = new QTableWidget(centralWidget);
        if (tableWidget->columnCount() < 3)
            tableWidget->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        if (tableWidget->rowCount() < 7)
            tableWidget->setRowCount(7);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(0, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(1, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(2, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(3, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(4, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(5, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(6, __qtablewidgetitem9);
        tableWidget->setObjectName("tableWidget");
        tableWidget->setGeometry(QRect(40, 150, 451, 291));
        tableWidget->setGridStyle(Qt::SolidLine);
        tableWidget->setSortingEnabled(false);
        tableWidget->horizontalHeader()->setVisible(false);
        tableWidget->horizontalHeader()->setDefaultSectionSize(120);
        tableWidget->verticalHeader()->setCascadingSectionResizes(false);
        tableWidget->verticalHeader()->setMinimumSectionSize(24);
        tableWidget->verticalHeader()->setDefaultSectionSize(40);
        tableWidget->verticalHeader()->setProperty("showSortIndicator", QVariant(false));
        tableWidget->verticalHeader()->setStretchLastSection(false);
        label = new QLabel(centralWidget);
        label->setObjectName("label");
        label->setGeometry(QRect(210, 50, 111, 41));
        QFont font;
        font.setPointSize(20);
        label->setFont(font);
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(470, 550, 75, 24));
        accountinfoClassClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(accountinfoClassClass);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 551, 22));
        accountinfoClassClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(accountinfoClassClass);
        mainToolBar->setObjectName("mainToolBar");
        accountinfoClassClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(accountinfoClassClass);
        statusBar->setObjectName("statusBar");
        accountinfoClassClass->setStatusBar(statusBar);

        retranslateUi(accountinfoClassClass);
        QObject::connect(pushButton, SIGNAL(clicked()), accountinfoClassClass, SLOT(goback()));

        QMetaObject::connectSlotsByName(accountinfoClassClass);
    } // setupUi

    void retranslateUi(QMainWindow *accountinfoClassClass)
    {
        accountinfoClassClass->setWindowTitle(QCoreApplication::translate("accountinfoClassClass", "accountinfoClass", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("accountinfoClassClass", "\354\234\240\354\240\200 \354\240\225\353\263\264", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->verticalHeaderItem(0);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("accountinfoClassClass", "\354\225\204\354\235\264\353\224\224", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->verticalHeaderItem(1);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("accountinfoClassClass", "\354\235\264\353\246\204", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->verticalHeaderItem(2);
        ___qtablewidgetitem3->setText(QCoreApplication::translate("accountinfoClassClass", "\354\203\235\353\205\204\354\233\224\354\235\274", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget->verticalHeaderItem(3);
        ___qtablewidgetitem4->setText(QCoreApplication::translate("accountinfoClassClass", "\353\214\200\354\227\254\352\260\200\353\212\245 \354\210\230", nullptr));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget->verticalHeaderItem(4);
        ___qtablewidgetitem5->setText(QCoreApplication::translate("accountinfoClassClass", "\353\214\200\354\227\254\355\225\234 \354\261\205", nullptr));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget->verticalHeaderItem(5);
        ___qtablewidgetitem6->setText(QCoreApplication::translate("accountinfoClassClass", "\354\261\205\353\263\204 \353\214\200\354\227\254\352\270\260\352\260\204", nullptr));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidget->verticalHeaderItem(6);
        ___qtablewidgetitem7->setText(QCoreApplication::translate("accountinfoClassClass", "\354\227\260\354\261\204\353\243\214", nullptr));
        label->setText(QCoreApplication::translate("accountinfoClassClass", "\355\232\214\354\233\220\354\240\225\353\263\264", nullptr));
        pushButton->setText(QCoreApplication::translate("accountinfoClassClass", "back", nullptr));
    } // retranslateUi

};

namespace Ui {
    class accountinfoClassClass: public Ui_accountinfoClassClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ACCOUNTINFOCLASS_H
