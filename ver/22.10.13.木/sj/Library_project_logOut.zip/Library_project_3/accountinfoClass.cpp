#include "accountinfoClass.h"

using namespace std;

accountinfoClass::accountinfoClass(QWidget *parent)
	: QMainWindow(parent)
{
	extern vector<string> loginuserinfo;
		   vector<QString> Qloginuserinfo;
		//string ���� Qstring ���ͷ� ��ȯ;
		std::transform(loginuserinfo.begin(), loginuserinfo.end(), std::back_inserter(Qloginuserinfo), [](const std::string& v) { return QString::fromStdString(v); });

	ui.setupUi(this);
	ui.tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
	ui.tableWidget->setItem(0, 0, new QTableWidgetItem(Qloginuserinfo[0]));
	ui.tableWidget->setItem(1, 0, new QTableWidgetItem(QString::fromLocal8Bit(loginuserinfo[2])));
	ui.tableWidget->setItem(2, 0, new QTableWidgetItem(Qloginuserinfo[3]));
	ui.tableWidget->setItem(3, 0, new QTableWidgetItem(Qloginuserinfo[5]));
	ui.tableWidget->setItem(4, 0, new QTableWidgetItem(QString::fromLocal8Bit(loginuserinfo[6])));
	ui.tableWidget->setItem(5, 0, new QTableWidgetItem(Qloginuserinfo[7]));
	ui.tableWidget->setItem(5, 0, new QTableWidgetItem(Qloginuserinfo[8]));

}

accountinfoClass::~accountinfoClass()
{}

void accountinfoClass::goback()
{
	close();
	QWidget* parent = this->parentWidget();
	parent->show();
}
