#include "BookBorrow.h"

BookBorrow::BookBorrow(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
}

BookBorrow::~BookBorrow()
{}
